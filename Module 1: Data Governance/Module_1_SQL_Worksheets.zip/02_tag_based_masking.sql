-- CERT: D2 Data Protection & Governance (30%) — tag-based masking, policy-tag association
-- ============================================================
-- MODULE 1C — ÉTAPE 2 : MASKING BASÉ SUR LES TAGS
-- ============================================================
-- Les tags existent DÉJÀ — posés par la classification en 1A :
--   • SENSIBILITE (TRES_SENSIBLE, SENSIBLE, INTERNE)
--   • RGPD (IDENTIFIANT_DIRECT, QUASI_IDENTIFIANT, DONNEE_SENSIBLE)
--   • SEMANTIC_CATEGORY (EMAIL, FR_PHONE, FR_IBAN, NAME, ...)
--
-- Les politiques existent DÉJÀ — créées en 1C/01 :
--   • MASK_PII_STRING  (STRING — branche sur SEMANTIC_CATEGORY)
--   • MASK_PII_DATE    (DATE)
--   • MASK_PII_NUMBER  (NUMBER)
--
-- Ce script fait UNE SEULE CHOSE : attacher les politiques au
-- tag SENSIBILITE. Zéro ALTER TABLE. Zéro tagging.
--
-- Pré-requis : 1A (classification + tags) + 1B (rôles) + 1C/01
-- ============================================================

USE ROLE ACCOUNTADMIN;
USE WAREHOUSE WORKSHOP_WH;

-- ────────────────────────────────────────────────────────────
-- A. VÉRIFIER LES TAGS EXISTANTS (posés en Module 1A)
-- ────────────────────────────────────────────────────────────
-- Avant d'attacher quoi que ce soit, on vérifie que les tags
-- sont bien là. Cette requête montre ce que la classification
-- a produit automatiquement + les gaps comblés manuellement.

SELECT
  TAG_NAME,
  TAG_VALUE,
  OBJECT_DATABASE || '.' || OBJECT_SCHEMA || '.' || OBJECT_NAME AS TABLE_CIBLE,
  COLUMN_NAME,
  APPLY_METHOD
FROM TABLE(VOLTAIRE_RH.INFORMATION_SCHEMA.TAG_REFERENCES_ALL_COLUMNS(
  'VOLTAIRE_RH.EMPLOYES.PERSONNEL', 'TABLE'))
WHERE TAG_NAME IN ('SENSIBILITE', 'RGPD', 'SEMANTIC_CATEGORY')
ORDER BY TAG_NAME, TAG_VALUE, COLUMN_NAME;

-- ────────────────────────────────────────────────────────────
-- B. TAG-BASED MASKING : ATTACHER LES POLITIQUES AU TAG
-- ────────────────────────────────────────────────────────────
-- Un tag peut porter UNE politique par type de données.
-- SENSIBILITE porte nos 3 politiques : STRING, DATE, NUMBER.
--
-- Dès qu'une colonne a le tag SENSIBILITE (quelle que soit la
-- valeur : TRES_SENSIBLE, SENSIBLE ou INTERNE), la politique
-- du bon type s'active automatiquement.

ALTER TAG VOLTAIRE_GOVERNANCE.TAGS.SENSIBILITE
  SET MASKING POLICY VOLTAIRE_GOVERNANCE.POLICIES.MASK_PII_STRING;

ALTER TAG VOLTAIRE_GOVERNANCE.TAGS.SENSIBILITE
  SET MASKING POLICY VOLTAIRE_GOVERNANCE.POLICIES.MASK_PII_DATE;

ALTER TAG VOLTAIRE_GOVERNANCE.TAGS.SENSIBILITE
  SET MASKING POLICY VOLTAIRE_GOVERNANCE.POLICIES.MASK_PII_NUMBER;

-- ────────────────────────────────────────────────────────────
-- C. VÉRIFICATION — QUELLES COLONNES SONT MASQUÉES ?
-- ────────────────────────────────────────────────────────────
-- POLICY_REFERENCES montre les politiques actives par table.
-- On devrait voir TOUTES les colonnes taguées SENSIBILITE
-- avec une politique de masking active (tag-based).

SELECT
  POLICY_NAME,
  REF_DATABASE_NAME || '.' || REF_SCHEMA_NAME || '.' || REF_ENTITY_NAME AS TABLE_CIBLE,
  REF_COLUMN_NAME AS COLONNE,
  TAG_NAME
FROM TABLE(SNOWFLAKE.INFORMATION_SCHEMA.POLICY_REFERENCES(
  REF_ENTITY_NAME => 'VOLTAIRE_RH.EMPLOYES.PERSONNEL', REF_ENTITY_DOMAIN => 'TABLE'))
WHERE POLICY_KIND = 'MASKING_POLICY'
UNION ALL
SELECT POLICY_NAME,
  REF_DATABASE_NAME || '.' || REF_SCHEMA_NAME || '.' || REF_ENTITY_NAME,
  REF_COLUMN_NAME, TAG_NAME
FROM TABLE(SNOWFLAKE.INFORMATION_SCHEMA.POLICY_REFERENCES(
  REF_ENTITY_NAME => 'VOLTAIRE_RH.PAIE.BULLETINS', REF_ENTITY_DOMAIN => 'TABLE'))
WHERE POLICY_KIND = 'MASKING_POLICY'
UNION ALL
SELECT POLICY_NAME,
  REF_DATABASE_NAME || '.' || REF_SCHEMA_NAME || '.' || REF_ENTITY_NAME,
  REF_COLUMN_NAME, TAG_NAME
FROM TABLE(SNOWFLAKE.INFORMATION_SCHEMA.POLICY_REFERENCES(
  REF_ENTITY_NAME => 'VOLTAIRE_CRM.CONTACTS.PERSONNES', REF_ENTITY_DOMAIN => 'TABLE'))
WHERE POLICY_KIND = 'MASKING_POLICY'
UNION ALL
SELECT POLICY_NAME,
  REF_DATABASE_NAME || '.' || REF_SCHEMA_NAME || '.' || REF_ENTITY_NAME,
  REF_COLUMN_NAME, TAG_NAME
FROM TABLE(SNOWFLAKE.INFORMATION_SCHEMA.POLICY_REFERENCES(
  REF_ENTITY_NAME => 'VOLTAIRE_FINANCE.COMPTABILITE.FACTURES', REF_ENTITY_DOMAIN => 'TABLE'))
WHERE POLICY_KIND = 'MASKING_POLICY'
UNION ALL
SELECT POLICY_NAME,
  REF_DATABASE_NAME || '.' || REF_SCHEMA_NAME || '.' || REF_ENTITY_NAME,
  REF_COLUMN_NAME, TAG_NAME
FROM TABLE(SNOWFLAKE.INFORMATION_SCHEMA.POLICY_REFERENCES(
  REF_ENTITY_NAME => 'VOLTAIRE_FINANCE.TRESORERIE.TRANSACTIONS', REF_ENTITY_DOMAIN => 'TABLE'))
WHERE POLICY_KIND = 'MASKING_POLICY'
ORDER BY 2, 3;

-- ────────────────────────────────────────────────────────────
-- D. TEST LIVE — VOIR LE MASKING EN ACTION
-- ────────────────────────────────────────────────────────────

USE ROLE DATA_ANALYST;
USE SECONDARY ROLES NONE;

SELECT NOM, EMAIL_PRO, TELEPHONE_PRO, NIR, IBAN, DATE_NAISSANCE
FROM VOLTAIRE_RH.EMPLOYES.PERSONNEL
LIMIT 5;

USE ROLE ACCOUNTADMIN;
