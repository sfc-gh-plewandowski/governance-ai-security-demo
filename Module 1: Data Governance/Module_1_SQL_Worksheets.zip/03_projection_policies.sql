-- CERT: D2 Data Protection & Governance (30%) — projection policies, column-level access restriction
-- ============================================================
-- MODULE 1C — ÉTAPE 3 : POLITIQUES DE PROJECTION
-- ============================================================
-- Une projection policy empêche une colonne d'apparaître
-- dans les résultats. Plus fort que le masking : la colonne
-- n'est même pas visible dans un SELECT *.
--
-- Cas d'usage : notes internes, champs médico-légaux,
-- commentaires managers, colonnes techniques sensibles.
--
-- NOTE : Les tag-based projection policies (ALTER TAG SET
-- PROJECTION POLICY) sont en Private Preview. En attendant
-- la GA, on attache les projections colonne par colonne.
--
-- Pré-requis : 01_masking_policies.sql exécuté
-- ============================================================

USE ROLE ACCOUNTADMIN;
USE WAREHOUSE WORKSHOP_WH;

-- ────────────────────────────────────────────────────────────
-- A. POLITIQUE DE PROJECTION — COLONNES RESTREINTES
-- ────────────────────────────────────────────────────────────
-- Seul SECURITY_ADMIN peut voir la colonne.
-- Tous les autres rôles : la colonne est exclue du résultat.

CREATE OR REPLACE PROJECTION POLICY VOLTAIRE_GOVERNANCE.POLICIES.HIDE_COLUMN_STRICT
AS () RETURNS PROJECTION_CONSTRAINT ->
  CASE
    WHEN IS_ROLE_IN_SESSION('SECURITY_ADMIN') THEN PROJECTION_CONSTRAINT(ALLOW => true)
    ELSE PROJECTION_CONSTRAINT(ALLOW => false)
  END;

-- ────────────────────────────────────────────────────────────
-- B. POLITIQUE DE PROJECTION — COLONNES INTERNES
-- ────────────────────────────────────────────────────────────
-- DATA_ENGINEER et SECURITY_ADMIN peuvent voir.
-- Les autres non.

CREATE OR REPLACE PROJECTION POLICY VOLTAIRE_GOVERNANCE.POLICIES.HIDE_COLUMN_INTERNE
AS () RETURNS PROJECTION_CONSTRAINT ->
  CASE
    WHEN IS_ROLE_IN_SESSION('SECURITY_ADMIN') THEN PROJECTION_CONSTRAINT(ALLOW => true)
    WHEN IS_ROLE_IN_SESSION('DATA_ENGINEER') THEN PROJECTION_CONSTRAINT(ALLOW => true)
    ELSE PROJECTION_CONSTRAINT(ALLOW => false)
  END;

-- ────────────────────────────────────────────────────────────
-- C. ATTACHER AUX COLONNES SENSIBLES
-- ────────────────────────────────────────────────────────────

ALTER TABLE VOLTAIRE_RH.EMPLOYES.PERSONNEL MODIFY COLUMN
  NIR SET PROJECTION POLICY VOLTAIRE_GOVERNANCE.POLICIES.HIDE_COLUMN_STRICT;

ALTER TABLE VOLTAIRE_RH.EMPLOYES.PERSONNEL MODIFY COLUMN
  NUMERO_PASSEPORT SET PROJECTION POLICY VOLTAIRE_GOVERNANCE.POLICIES.HIDE_COLUMN_STRICT;

ALTER TABLE VOLTAIRE_RH.RECRUTEMENT.CANDIDATS MODIFY COLUMN
  SALAIRE_SOUHAITE SET PROJECTION POLICY VOLTAIRE_GOVERNANCE.POLICIES.HIDE_COLUMN_INTERNE;

ALTER TABLE VOLTAIRE_DATALAKE.RAW.ACCESS_LOGS MODIFY COLUMN
  PAYLOAD SET PROJECTION POLICY VOLTAIRE_GOVERNANCE.POLICIES.HIDE_COLUMN_INTERNE;

-- ────────────────────────────────────────────────────────────
-- D. VÉRIFICATION
-- ────────────────────────────────────────────────────────────

SELECT POLICY_NAME, REF_COLUMN_NAME AS COLONNE,
  REF_DATABASE_NAME || '.' || REF_SCHEMA_NAME || '.' || REF_ENTITY_NAME AS TABLE_CIBLE
FROM TABLE(SNOWFLAKE.INFORMATION_SCHEMA.POLICY_REFERENCES(
  REF_ENTITY_NAME => 'VOLTAIRE_RH.EMPLOYES.PERSONNEL', REF_ENTITY_DOMAIN => 'TABLE'))
WHERE POLICY_KIND = 'PROJECTION_POLICY'
UNION ALL
SELECT POLICY_NAME, REF_COLUMN_NAME,
  REF_DATABASE_NAME || '.' || REF_SCHEMA_NAME || '.' || REF_ENTITY_NAME
FROM TABLE(SNOWFLAKE.INFORMATION_SCHEMA.POLICY_REFERENCES(
  REF_ENTITY_NAME => 'VOLTAIRE_RH.RECRUTEMENT.CANDIDATS', REF_ENTITY_DOMAIN => 'TABLE'))
WHERE POLICY_KIND = 'PROJECTION_POLICY'
UNION ALL
SELECT POLICY_NAME, REF_COLUMN_NAME,
  REF_DATABASE_NAME || '.' || REF_SCHEMA_NAME || '.' || REF_ENTITY_NAME
FROM TABLE(SNOWFLAKE.INFORMATION_SCHEMA.POLICY_REFERENCES(
  REF_ENTITY_NAME => 'VOLTAIRE_DATALAKE.RAW.ACCESS_LOGS', REF_ENTITY_DOMAIN => 'TABLE'))
WHERE POLICY_KIND = 'PROJECTION_POLICY'
ORDER BY 3, 2;
